import { c as createAstro, a as createComponent, r as renderTemplate, m as maybeRenderHead, b as renderComponent, d as addAttribute, e as renderSlot, f as renderHead } from './c.f0e5e627.js';
import './c.5106a4fb.js';

function noop() { }
function run(fn) {
    return fn();
}
function blank_object() {
    return Object.create(null);
}
function run_all(fns) {
    fns.forEach(run);
}
function is_function(thing) {
    return typeof thing === 'function';
}
function safe_not_equal(a, b) {
    return a != a ? b == b : a !== b || ((a && typeof a === 'object') || typeof a === 'function');
}
function subscribe(store, ...callbacks) {
    if (store == null) {
        return noop;
    }
    const unsub = store.subscribe(...callbacks);
    return unsub.unsubscribe ? () => unsub.unsubscribe() : unsub;
}
function null_to_empty(value) {
    return value == null ? '' : value;
}

let current_component;
function set_current_component(component) {
    current_component = component;
}
Promise.resolve();
const ATTR_REGEX = /[&"]/g;
const CONTENT_REGEX = /[&<]/g;
/**
 * Note: this method is performance sensitive and has been optimized
 * https://github.com/sveltejs/svelte/pull/5701
 */
function escape(value, is_attr = false) {
    const str = String(value);
    const pattern = is_attr ? ATTR_REGEX : CONTENT_REGEX;
    pattern.lastIndex = 0;
    let escaped = '';
    let last = 0;
    while (pattern.test(str)) {
        const i = pattern.lastIndex - 1;
        const ch = str[i];
        escaped += str.substring(last, i) + (ch === '&' ? '&amp;' : (ch === '"' ? '&quot;' : '&lt;'));
        last = i + 1;
    }
    return escaped + str.substring(last);
}
function escape_attribute_value(value) {
    // keep booleans, null, and undefined for the sake of `spread`
    const should_escape = typeof value === 'string' || (value && typeof value === 'object');
    return should_escape ? escape(value, true) : value;
}
function each(items, fn) {
    let str = '';
    for (let i = 0; i < items.length; i += 1) {
        str += fn(items[i], i);
    }
    return str;
}
const missing_component = {
    $$render: () => ''
};
function validate_component(component, name) {
    if (!component || !component.$$render) {
        if (name === 'svelte:component')
            name += ' this={...}';
        throw new Error(`<${name}> is not a valid SSR component. You may need to review your build config to ensure that dependencies are compiled, rather than imported as pre-compiled modules. Otherwise you may need to fix a <${name}>.`);
    }
    return component;
}
let on_destroy;
function create_ssr_component(fn) {
    function $$render(result, props, bindings, slots, context) {
        const parent_component = current_component;
        const $$ = {
            on_destroy,
            context: new Map(context || (parent_component ? parent_component.$$.context : [])),
            // these will be immediately discarded
            on_mount: [],
            before_update: [],
            after_update: [],
            callbacks: blank_object()
        };
        set_current_component({ $$ });
        const html = fn(result, props, bindings, slots);
        set_current_component(parent_component);
        return html;
    }
    return {
        render: (props = {}, { $$slots = {}, context = new Map() } = {}) => {
            on_destroy = [];
            const result = { title: '', head: '', css: new Set() };
            const html = $$render(result, props, {}, $$slots, context);
            run_all(on_destroy);
            return {
                html,
                css: {
                    code: Array.from(result.css).map(css => css.code).join('\n'),
                    map: null // TODO
                },
                head: result.title + result.head
            };
        },
        $$render
    };
}
function add_attribute(name, value, boolean) {
    if (value == null || (boolean && !value))
        return '';
    const assignment = (boolean && value === true) ? '' : `="${escape(value, true)}"`;
    return ` ${name}${assignment}`;
}
function style_object_to_string(style_object) {
    return Object.keys(style_object)
        .filter(key => style_object[key])
        .map(key => `${key}: ${escape_attribute_value(style_object[key])};`)
        .join(' ');
}
function add_styles(style_object) {
    const styles = style_object_to_string(style_object);
    return styles ? ` style="${styles}"` : '';
}

const subscriber_queue = [];
/**
 * Creates a `Readable` store that allows reading by subscription.
 * @param value initial value
 * @param {StartStopNotifier}start start and stop notifications for subscriptions
 */
function readable(value, start) {
    return {
        subscribe: writable(value, start).subscribe
    };
}
/**
 * Create a `Writable` store that allows both updating and reading by subscription.
 * @param {*=}value initial value
 * @param {StartStopNotifier=}start start and stop notifications for subscriptions
 */
function writable(value, start = noop) {
    let stop;
    const subscribers = new Set();
    function set(new_value) {
        if (safe_not_equal(value, new_value)) {
            value = new_value;
            if (stop) { // store is ready
                const run_queue = !subscriber_queue.length;
                for (const subscriber of subscribers) {
                    subscriber[1]();
                    subscriber_queue.push(subscriber, value);
                }
                if (run_queue) {
                    for (let i = 0; i < subscriber_queue.length; i += 2) {
                        subscriber_queue[i][0](subscriber_queue[i + 1]);
                    }
                    subscriber_queue.length = 0;
                }
            }
        }
    }
    function update(fn) {
        set(fn(value));
    }
    function subscribe(run, invalidate = noop) {
        const subscriber = [run, invalidate];
        subscribers.add(subscriber);
        if (subscribers.size === 1) {
            stop = start(set) || noop;
        }
        run(value);
        return () => {
            subscribers.delete(subscriber);
            if (subscribers.size === 0) {
                stop();
                stop = null;
            }
        };
    }
    return { set, update, subscribe };
}
function derived(stores, fn, initial_value) {
    const single = !Array.isArray(stores);
    const stores_array = single
        ? [stores]
        : stores;
    const auto = fn.length < 2;
    return readable(initial_value, (set) => {
        let inited = false;
        const values = [];
        let pending = 0;
        let cleanup = noop;
        const sync = () => {
            if (pending) {
                return;
            }
            cleanup();
            const result = fn(single ? values[0] : values, set);
            if (auto) {
                set(result);
            }
            else {
                cleanup = is_function(result) ? result : noop;
            }
        };
        const unsubscribers = stores_array.map((store, i) => subscribe(store, (value) => {
            values[i] = value;
            pending &= ~(1 << i);
            if (inited) {
                sync();
            }
        }, () => {
            pending |= (1 << i);
        }));
        inited = true;
        sync();
        return function stop() {
            run_all(unsubscribers);
            cleanup();
        };
    });
}

const MS_A_SECOND = 1e3;
const SECONDS_A_MINUTE = 60;
const MINUTES_A_HOUR = 60;
const HOURS_A_DAY = 24;
const MONTHS_A_YEAR = 12;
const MS_A_MINUTE = SECONDS_A_MINUTE * MS_A_SECOND;
const MS_A_DAY = HOURS_A_DAY * MINUTES_A_HOUR * MS_A_MINUTE;
function absFloor(value) {
  return value < 0 ? Math.ceil(value) || 0 : Math.floor(value);
}
function utcOffset(date) {
  return -Math.round(date.getTimezoneOffset() / 15) * 15;
}
function getDaysDiff(from, to) {
  const zoneDelta = (utcOffset(to) - utcOffset(from)) / MS_A_MINUTE;
  const diff = from.getTime() - to.getTime();
  return absFloor((diff - zoneDelta) / MS_A_DAY);
}
function getDaysInMonth(date) {
  return new Date(
    date.getFullYear(),
    date.getMonth() + 1,
    0
  ).getDate();
}
function addMonth(date, month) {
  const result = new Date(date);
  result.setDate(1);
  result.setMonth(date.getMonth() + month);
  result.setDate(Math.min(date.getDate(), getDaysInMonth(result)));
  return result;
}
function getMonthDiff(from, to) {
  if (from.getDate() < to.getDate())
    return -getMonthDiff(to, from);
  const wholeMonthDiff = (to.getFullYear() - from.getFullYear()) * MONTHS_A_YEAR + (to.getMonth() - from.getMonth());
  const firstAnchor = addMonth(from, wholeMonthDiff);
  const diffWithFirstAnchor = to.getTime() - firstAnchor.getTime();
  const isFirstAnchorExceed = diffWithFirstAnchor < 0;
  const secondAnchor = addMonth(
    from,
    wholeMonthDiff + (isFirstAnchorExceed ? -1 : 1)
  );
  const diffOfset = diffWithFirstAnchor / Math.abs(firstAnchor.getTime() - secondAnchor.getTime());
  return +(-(wholeMonthDiff + diffOfset) || 0);
}
function zeroPad(value) {
  return value.toString().padStart(2, "0");
}
function formatDate(date) {
  if (!date)
    return "";
  return [
    zeroPad(date.getDate()),
    zeroPad(date.getMonth() + 1),
    date.getFullYear()
  ].join("-");
}

const birthdate = writable();
const ONE_DAY_UNITS = ["second", "minute", "hour"];
const ONE_DAY_UNIT_CONVERSIONS = [
  SECONDS_A_MINUTE,
  MINUTES_A_HOUR,
  HOURS_A_DAY
];
function getAgeDetailForOneDay(currentDate, dateOfBirth) {
  const ageDetail = {};
  let diff = absFloor(
    (currentDate.getTime() - dateOfBirth.getTime()) / MS_A_SECOND
  );
  ONE_DAY_UNITS.forEach((unit, index) => {
    const conversion = ONE_DAY_UNIT_CONVERSIONS[index];
    const remaining = ageDetail[unit] = diff % conversion;
    diff = (diff - remaining) / conversion;
  });
  return ageDetail;
}
function getRemainingDaysUnderAMonth(currentDate, dateOfBirth) {
  const dateOnlyDOB = dateOfBirth.getDate();
  const birthdateInCurrentMonthAndYear = new Date(currentDate);
  birthdateInCurrentMonthAndYear.setDate(dateOnlyDOB);
  if (currentDate.getDate() === dateOnlyDOB)
    return 0;
  if (currentDate.getDate() > dateOnlyDOB) {
    return getDaysDiff(currentDate, birthdateInCurrentMonthAndYear);
  }
  const lastMonth = addMonth(birthdateInCurrentMonthAndYear, -1);
  return getDaysDiff(currentDate, lastMonth);
}
function getAgeDetail(dateOfBirth) {
  if (!dateOfBirth)
    return {};
  const now = /* @__PURE__ */ new Date();
  const monthDiff = getMonthDiff(now, dateOfBirth);
  const ageDetail = getAgeDetailForOneDay(now, dateOfBirth);
  ageDetail.day = getRemainingDaysUnderAMonth(now, dateOfBirth);
  ageDetail.month = absFloor(monthDiff % MONTHS_A_YEAR);
  ageDetail.year = absFloor(monthDiff / MONTHS_A_YEAR);
  return ageDetail;
}
function getMaxDaysInCurrentMonth(dateOfBirth) {
  if (!dateOfBirth)
    return 30;
  const now = /* @__PURE__ */ new Date();
  const dobThisMonthAndYear = new Date(dateOfBirth);
  dobThisMonthAndYear.setFullYear(now.getFullYear(), now.getMonth());
  const diff = now.getTime() - dobThisMonthAndYear.getTime();
  if (diff >= 0)
    return getDaysInMonth(now);
  return getDaysInMonth(addMonth(now, -1));
}
const age = derived(
  birthdate,
  ($birthdate, set) => {
    const ageDetail = getAgeDetail($birthdate);
    set(ageDetail);
    const maxDaysInMonth = getMaxDaysInCurrentMonth($birthdate);
    const interval = setInterval(() => {
      if (typeof ageDetail.second === "undefined")
        return;
      if (ageDetail.second < SECONDS_A_MINUTE - 1) {
        ageDetail.second++;
        set({ ...ageDetail });
        return;
      }
      if (typeof ageDetail.minute === "undefined")
        return;
      ageDetail.second = 0;
      if (ageDetail.minute < MINUTES_A_HOUR - 1) {
        ageDetail.minute++;
        set({ ...ageDetail });
        return;
      }
      if (typeof ageDetail.hour === "undefined")
        return;
      ageDetail.minute = 0;
      if (ageDetail.hour < HOURS_A_DAY - 1) {
        ageDetail.hour++;
        set({ ...ageDetail });
        return;
      }
      if (typeof ageDetail.day === "undefined")
        return;
      ageDetail.hour = 0;
      if (ageDetail.day < maxDaysInMonth - 1) {
        ageDetail.day++;
        set({ ...ageDetail });
        return;
      }
      if (typeof ageDetail.month === "undefined")
        return;
      ageDetail.day = 0;
      if (ageDetail.month < MONTHS_A_YEAR - 1) {
        ageDetail.month++;
        set({ ...ageDetail });
        return;
      }
      if (typeof ageDetail.year === "undefined")
        return;
      ageDetail.month = 0;
      ageDetail.year++;
      set({ ...ageDetail });
    }, MS_A_SECOND);
    return () => {
      clearInterval(interval);
    };
  },
  {}
);
const isBirthdayParty = derived(age, ($age) => {
  return $age.day === 0 && $age.month === 0;
});

/* src/components/age/components/UnitLabel.svelte generated by Svelte v3.55.0 */

const UnitLabel = create_ssr_component(($$result, $$props, $$bindings, slots) => {
	let label;
	let $age, $$unsubscribe_age;
	$$unsubscribe_age = subscribe(age, value => $age = value);
	let { class: className = "" } = $$props;
	let { unit } = $$props;
	if ($$props.class === void 0 && $$bindings.class && className !== void 0) $$bindings.class(className);
	if ($$props.unit === void 0 && $$bindings.unit && unit !== void 0) $$bindings.unit(unit);
	label = unit.replace(/^\S/g, match => match.toUpperCase()) + ($age[unit] > 1 ? "s" : "");
	$$unsubscribe_age();
	return `<span${add_attribute("class", className, 0)}>${escape(label)}</span>`;
});

/* src/components/age/components/UnitValue.svelte generated by Svelte v3.55.0 */

const UnitValue = create_ssr_component(($$result, $$props, $$bindings, slots) => {
	let $age, $$unsubscribe_age;
	$$unsubscribe_age = subscribe(age, value => $age = value);
	let { class: className = "" } = $$props;
	let { unit } = $$props;
	if ($$props.class === void 0 && $$bindings.class && className !== void 0) $$bindings.class(className);
	if ($$props.unit === void 0 && $$bindings.unit && unit !== void 0) $$bindings.unit(unit);
	$$unsubscribe_age();
	return `<span${add_attribute("class", className, 0)}>${escape($age[unit] ?? '')}</span>`;
});

const $$Astro$6 = createAstro("https://age.rofi.link");
const $$AgeUnit = createComponent(async ($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$6, $$props, $$slots);
  Astro2.self = $$AgeUnit;
  const { unit } = Astro2.props;
  return renderTemplate`${maybeRenderHead($$result)}<div class="age-unit astro-VX2QHHYE"><div class="unit-value astro-VX2QHHYE">${renderComponent($$result, "UnitValue", UnitValue, { "client:load": true, "unit": unit, "client:component-hydration": "load", "client:component-path": "/Volumes/source-code/rofi/age-calculator-astro/src/components/age/components/UnitValue.svelte", "client:component-export": "default", "class": "astro-VX2QHHYE" })}</div><div class="unit-label astro-VX2QHHYE">${renderComponent($$result, "UnitLabel", UnitLabel, { "client:load": true, "unit": unit, "client:component-hydration": "load", "client:component-path": "/Volumes/source-code/rofi/age-calculator-astro/src/components/age/components/UnitLabel.svelte", "client:component-export": "default", "class": "astro-VX2QHHYE" })}</div></div>`;
}, "/Volumes/source-code/rofi/age-calculator-astro/src/components/age/components/AgeUnit.astro");

const $$Astro$5 = createAstro("https://age.rofi.link");
const $$Age = createComponent(async ($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$5, $$props, $$slots);
  Astro2.self = $$Age;
  const ageUnitsMajor = ["year", "month", "day"];
  const ageUnitsMinor = ["hour", "minute", "second"];
  return renderTemplate`${maybeRenderHead($$result)}<main class="astro-FR3OFCMB"><h1 class="astro-FR3OFCMB">Age</h1><div class="age-unit-major astro-FR3OFCMB">${ageUnitsMajor.map((unit) => renderTemplate`${renderComponent($$result, "AgeUnit", $$AgeUnit, { "unit": unit, "class": "astro-FR3OFCMB" })}`)}</div><div class="age-unit-minor astro-FR3OFCMB">${ageUnitsMinor.map((unit) => renderTemplate`${renderComponent($$result, "AgeUnit", $$AgeUnit, { "unit": unit, "class": "astro-FR3OFCMB" })}`)}</div></main>`;
}, "/Volumes/source-code/rofi/age-calculator-astro/src/components/age/Age.astro");

/* src/components/BirthdayParty.svelte generated by Svelte v3.55.0 */

const css$3 = {
	code: ".container.svelte-5fw5py{position:fixed;z-index:-1;display:flex;align-items:center;justify-content:center;width:100svw;height:100svh;overflow:hidden}[data-sidebar-open] .container.svelte-5fw5py{width:calc(100svw - var(--sidebar-width))}",
	map: null
};

const BirthdayParty = create_ssr_component(($$result, $$props, $$bindings, slots) => {
	let $isBirthdayParty, $$unsubscribe_isBirthdayParty;
	$$unsubscribe_isBirthdayParty = subscribe(isBirthdayParty, value => $isBirthdayParty = value);
	let { class: className = "" } = $$props;
	let Confetti;
	if ($$props.class === void 0 && $$bindings.class && className !== void 0) $$bindings.class(className);
	$$result.css.add(css$3);

	{
		if ($isBirthdayParty && !Confetti) {
			import('./c.1129ff68.js').then(mod => {
				Confetti = mod.Confetti;
			});
		}
	}

	$$unsubscribe_isBirthdayParty();

	return `${$isBirthdayParty && Confetti
	? `<div class="${[
			escape(null_to_empty(className), true) + " svelte-5fw5py",
			"container" 
		].join(' ').trim()}">${validate_component(Confetti || missing_component, "svelte:component").$$render(
			$$result,
			{
				amount: 1000,
				fallDistance: "100vh",
				infinite: true,
				xSpread: 0.5,
				x: [-5, 5],
				y: [-5, 5]
			},
			{},
			{}
		)}</div>`
	: ``}`;
});

const $$Astro$4 = createAstro("https://age.rofi.link");
const $$Footer = createComponent(async ($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$4, $$props, $$slots);
  Astro2.self = $$Footer;
  return renderTemplate`${maybeRenderHead($$result)}<footer class="astro-SZ7XMLTE"><p class="astro-SZ7XMLTE">${`Copyright \xA9 ${( new Date()).getFullYear()} `}<a${addAttribute("https://github.com/RofiSyahrul/age-calculator.git", "href")} target="_blank" class="astro-SZ7XMLTE">Rofi</a>${"."}</p><p class="astro-SZ7XMLTE">${`v${"4.0.0"}`}</p></footer>`;
}, "/Volumes/source-code/rofi/age-calculator-astro/src/components/Footer.astro");

/* src/components/ToggleSidebarButton.svelte generated by Svelte v3.55.0 */

const ToggleSidebarButton = create_ssr_component(($$result, $$props, $$bindings, slots) => {
	let { class: className } = $$props;
	let { title } = $$props;
	if ($$props.class === void 0 && $$bindings.class && className !== void 0) $$bindings.class(className);
	if ($$props.title === void 0 && $$bindings.title && title !== void 0) $$bindings.title(title);
	return `<button${add_attribute("aria-label", title, 0)}${add_attribute("class", className, 0)}${add_attribute("title", title, 0)}>${slots.default ? slots.default({}) : ``}</button>`;
});

const $$Astro$3 = createAstro("https://age.rofi.link");
const $$CloseButton = createComponent(async ($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$3, $$props, $$slots);
  Astro2.self = $$CloseButton;
  return renderTemplate`${renderComponent($$result, "ToggleSidebarButton", ToggleSidebarButton, { "class": "close-btn astro-FLSEIVWQ", "title": "Close Sidebar", "client:idle": true, "client:component-hydration": "idle", "client:component-path": "~/components/ToggleSidebarButton.svelte", "client:component-export": "default" }, { "default": ($$result2) => renderTemplate`${maybeRenderHead($$result2)}<svg aria-label="Close Icon" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="32" height="32" viewBox="0 0 32 32" class="astro-FLSEIVWQ"><g fill="none" class="astro-FLSEIVWQ"><path fill="none" d="M0 0H32V32H0z" class="astro-FLSEIVWQ"></path><path fill="currentcolor" d="M24 8c.187.186.292.44.292.703 0 .264-.105.517-.292.704l-5.893 5.926c-.387.392-.387 1.022 0 1.414L24 22.6c.299.398.259.955-.093 1.307s-.909.392-1.307.093l-5.893-5.893c-.392-.387-1.022-.387-1.414 0L9.4 24c-.331.442-.958.531-1.4.2-.442-.331-.531-.958-.2-1.4.06-.073.127-.14.2-.2l5.893-5.893c.387-.392.387-1.022 0-1.414L8 9.4c-.442-.331-.531-.958-.2-1.4.331-.442.958-.531 1.4-.2.073.06.14.127.2.2l5.893 5.893c.392.387 1.022.387 1.414 0L22.6 8c.185-.186.437-.291.7-.291.263 0 .515.105.7.291z" class="astro-FLSEIVWQ"></path></g></svg>` })}`;
}, "/Volumes/source-code/rofi/age-calculator-astro/src/components/sidebar/components/CloseButton.astro");

const DEFAULT_COLORS = {
  background: "#09122d",
  primary: "#28476c",
  secondary: "#b7eae9",
  text: "#daecf2"
};

const colors = writable(DEFAULT_COLORS);
const isDefaultColors = derived(colors, ($colors) => {
  for (const key in $colors) {
    const colorName = key;
    const newColor = $colors[colorName];
    if (newColor !== DEFAULT_COLORS[colorName]) {
      return false;
    }
  }
  return true;
});
({ ...DEFAULT_COLORS });

/* src/components/sidebar/components/color-picker/ColorPicker.svelte generated by Svelte v3.55.0 */

const css$2 = {
	code: ".color-picker.svelte-79bqi0.svelte-79bqi0{position:relative;display:flex;flex-direction:column;align-items:center;justify-content:center;width:100%}.trigger.svelte-79bqi0 button.svelte-79bqi0{width:20px;min-height:20px;border:1px solid var(--color-text);border-radius:50%}",
	map: null
};

const ColorPicker = create_ssr_component(($$result, $$props, $$bindings, slots) => {
	let $colors, $$unsubscribe_colors;
	$$unsubscribe_colors = subscribe(colors, value => $colors = value);
	let { class: className = "" } = $$props;
	let { colorName = "background" } = $$props;
	let { description = "" } = $$props;

	const buttonID = `color-picker-trigger__${colorName}`;
	const descriptionID = `color-picker-description__${colorName}`;
	const a11yTextColors = [{ name: "text", isTextColor: true }, { name: "secondary", isTextColor: true }];
	const a11yBgColors = [{ name: "background" }, { name: "primary" }];

	const a11yColorsMapping = {
		background: a11yTextColors,
		primary: [...a11yTextColors, { name: "text" }],
		secondary: a11yBgColors,
		text: [...a11yBgColors, { name: "primary", isTextColor: true }]
	};

	if ($$props.class === void 0 && $$bindings.class && className !== void 0) $$bindings.class(className);
	if ($$props.colorName === void 0 && $$bindings.colorName && colorName !== void 0) $$bindings.colorName(colorName);
	if ($$props.description === void 0 && $$bindings.description && description !== void 0) $$bindings.description(description);
	$$result.css.add(css$2);
	let $$settled;
	let $$rendered;

	do {
		$$settled = true;

		a11yColorsMapping[colorName].map(({ name, isTextColor }) => ({ hex: $colors[name], reverse: isTextColor }));

		$$rendered = `<div class="${[
			escape(null_to_empty(className), true) + " svelte-79bqi0",
			"color-picker" 
		].join(' ').trim()}"><label class="${"trigger svelte-79bqi0"}"${add_attribute("for", buttonID, 0)} title="${"Change color here"}"><button${add_attribute("aria-labelledby", descriptionID, 0)}${add_attribute("id", buttonID, 0)} class="${"svelte-79bqi0"}"${add_styles({ "--bg-btn": `var(--color-${colorName})` })}></button>
    <div${add_attribute("id", descriptionID, 0)}>${escape(description)}</div></label>

  ${``}
</div>`;
	} while (!$$settled);

	$$unsubscribe_colors();
	return $$rendered;
});

/* src/components/sidebar/components/DatePicker.svelte generated by Svelte v3.55.0 */

const css$1 = {
	code: ".datepicker.svelte-1rsnyqo.svelte-1rsnyqo{position:relative}.trigger.svelte-1rsnyqo.svelte-1rsnyqo{justify-content:space-between}.trigger.svelte-1rsnyqo button.svelte-1rsnyqo{--bg-btn:transparent;color:inherit}.calendar.svelte-1rsnyqo.svelte-1rsnyqo{position:absolute;top:100%;left:0;z-index:var(--popover-z-index);display:none;justify-content:center;width:100%;margin-top:4px}.calendar[open].svelte-1rsnyqo.svelte-1rsnyqo{display:flex}.calendar.svelte-1rsnyqo .grid{border-radius:8px}.calendar.svelte-1rsnyqo .grid .controls{border-radius:8px 8px 0 0}.calendar.svelte-1rsnyqo .grid a{-webkit-user-select:none;-moz-user-select:none;user-select:none}",
	map: null
};

const DatePicker = create_ssr_component(($$result, $$props, $$bindings, slots) => {
	let formattedDate;

	let $birthdate, $$unsubscribe_birthdate;
	$$unsubscribe_birthdate = subscribe(birthdate, value => $birthdate = value);
	let { class: className = "" } = $$props;

	if ($$props.class === void 0 && $$bindings.class && className !== void 0) $$bindings.class(className);
	$$result.css.add(css$1);
	let $$settled;
	let $$rendered;

	do {
		$$settled = true;
		formattedDate = formatDate($birthdate);

		$$rendered = `<div class="${[
			escape(null_to_empty(className), true) + " svelte-1rsnyqo",
			"datepicker" 
		].join(' ').trim()}"><label class="${"trigger svelte-1rsnyqo"}" title="${"Change birthdate here"}">Birthdate
    <button class="${"svelte-1rsnyqo"}">${escape(formattedDate)}</button></label>
  ${``}
</div>`;
	} while (!$$settled);
	$$unsubscribe_birthdate();
	return $$rendered;
});

/* src/components/sidebar/components/ResetColorButton.svelte generated by Svelte v3.55.0 */

const css = {
	code: "button.svelte-1xwn4dy{--bg-btn:var(--color-secondary);align-self:flex-end;width:-moz-fit-content;width:fit-content;max-width:100%;min-height:40px;padding:0 12px;color:var(--color-background)}button.svelte-1xwn4dy:not(:disabled){box-shadow:var(--shadow-high)}",
	map: null
};

const ResetColorButton = create_ssr_component(($$result, $$props, $$bindings, slots) => {
	let $$unsubscribe_colors;
	let $isDefaultColors, $$unsubscribe_isDefaultColors;
	$$unsubscribe_colors = subscribe(colors, value => value);
	$$unsubscribe_isDefaultColors = subscribe(isDefaultColors, value => $isDefaultColors = value);
	let { class: className = "" } = $$props;

	if ($$props.class === void 0 && $$bindings.class && className !== void 0) $$bindings.class(className);
	$$result.css.add(css);
	$$unsubscribe_colors();
	$$unsubscribe_isDefaultColors();

	return `<button class="${escape(null_to_empty(className), true) + " svelte-1xwn4dy"}" ${$isDefaultColors ? "disabled" : ""}>Reset colors to default
</button>`;
});

const $$Astro$2 = createAstro("https://age.rofi.link");
const $$Sidebar = createComponent(async ($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$2, $$props, $$slots);
  Astro2.self = $$Sidebar;
  const colorData = [
    { colorName: "background", description: "Background color" },
    {
      colorName: "primary",
      description: "Circle and picker color"
    },
    {
      colorName: "secondary",
      description: "Age, units, icons, and numbers color"
    },
    { colorName: "text", description: "Text color" }
  ];
  return renderTemplate`${maybeRenderHead($$result)}<aside class="astro-BFS7PDWZ"><div class="close-btn-wrapper astro-BFS7PDWZ">${renderComponent($$result, "CloseButton", $$CloseButton, { "class": "astro-BFS7PDWZ" })}</div>${renderComponent($$result, "DatePicker", DatePicker, { "class": "picker astro-BFS7PDWZ", "client:idle": true, "client:component-hydration": "idle", "client:component-path": "/Volumes/source-code/rofi/age-calculator-astro/src/components/sidebar/components/DatePicker.svelte", "client:component-export": "default" })}${colorData.map(({ colorName, description }) => renderTemplate`${renderComponent($$result, "ColorPicker", ColorPicker, { "colorName": colorName, "description": description, "class": "picker astro-BFS7PDWZ", "client:idle": true, "client:component-hydration": "idle", "client:component-path": "/Volumes/source-code/rofi/age-calculator-astro/src/components/sidebar/components/color-picker/ColorPicker.svelte", "client:component-export": "default" })}`)}${renderComponent($$result, "ResetColorButton", ResetColorButton, { "client:idle": true, "client:component-hydration": "idle", "client:component-path": "/Volumes/source-code/rofi/age-calculator-astro/src/components/sidebar/components/ResetColorButton.svelte", "client:component-export": "default", "class": "astro-BFS7PDWZ" })}</aside>`;
}, "/Volumes/source-code/rofi/age-calculator-astro/src/components/sidebar/Sidebar.astro");

const $$Astro$1 = createAstro("https://age.rofi.link");
const $$Layout = createComponent(async ($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$1, $$props, $$slots);
  Astro2.self = $$Layout;
  const {
    canonicalURL = "https://age.rofi.link",
    description = "Age Calculator and Updater as Chrome Extension by Rofi",
    imageURL = "https://res.cloudinary.com/rofi/image/upload/v1640233522/samples/rho-pi.png",
    title
  } = Astro2.props;
  const faviconURL = "/favicon.ico";
  return renderTemplate`<html lang="en"${addAttribute({
    "--bg": DEFAULT_COLORS.background,
    "--p": DEFAULT_COLORS.primary,
    "--s": DEFAULT_COLORS.secondary,
    "--t": DEFAULT_COLORS.text
  }, "style")}><head><meta charset="UTF-8"><meta http-equiv="x-UA-Compatible" content="ie=edge"><meta name="generator"${addAttribute(Astro2.generator, "content")}><meta name="viewport" content="width=device-width,initial-scale=1.0"><link rel="icon"${addAttribute(faviconURL, "href")}><link rel="manifest" href="/manifest.json"><link rel="canonical"${addAttribute(canonicalURL, "href")}><title>${title}</title><link rel="apple-touch-icon"${addAttribute(faviconURL, "href")}><meta property="og:type" content="website"><meta property="og:title"${addAttribute(title, "content")}><meta property="og:image"${addAttribute(imageURL, "content")}><meta property="og:url"${addAttribute(canonicalURL, "content")}><meta property="og:description"${addAttribute(description, "content")}><meta name="description"${addAttribute(description, "content")}><meta name="author" content="Rofi"><meta name="image"${addAttribute(imageURL, "content")}><meta name="keywords" content="chrome, extension, chrome extension, age calculator, calculate your age"><meta name="mobile-web-app-capable" content="yes"><meta name="apple-mobile-web-app-capable" content="yes"><meta name="apple-mobile-web-app-title"${addAttribute("Age Calculator and Updater", "content")}><meta name="apple-mobile-web-app-status-bar-style" content="black-translucent"><meta name="apple-touch-icon"${addAttribute(faviconURL, "content")}><meta name="application-name"${addAttribute("Age Calculator and Updater", "content")}><meta name="theme-color"${addAttribute("#28476c", "content")}><meta name="msapplication-TileColor"${addAttribute("#28476c", "content")}><meta name="twitter:title"${addAttribute(title, "content")}><meta name="twitter:description"${addAttribute(description, "content")}><meta name="twitter:image"${addAttribute(imageURL, "content")}><meta name="twitter:creator" content="@RofiSyahrul"><meta name="twitter:dnt" content="on"><meta name="twitter:card" content="summary_large_image">${!true }${renderSlot($$result, $$slots["head"])}${renderHead($$result)}</head><body>${renderSlot($$result, $$slots["default"])}</body></html>`;
}, "/Volumes/source-code/rofi/age-calculator-astro/src/layouts/Layout.astro");

const $$Astro = createAstro("https://age.rofi.link");
const $$Index = createComponent(async ($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro, $$props, $$slots);
  Astro2.self = $$Index;
  return renderTemplate`${renderComponent($$result, "Layout", $$Layout, { "title": "New Tab" , "class": "astro-J7PV25F6" }, { "default": ($$result2) => renderTemplate`${renderComponent($$result2, "Age", $$Age, { "class": "astro-J7PV25F6" })}${renderComponent($$result2, "Sidebar", $$Sidebar, { "class": "astro-J7PV25F6" })}${renderComponent($$result2, "ToggleSidebarButton", ToggleSidebarButton, { "class": "setting-btn astro-J7PV25F6", "title": "Open Sidebar", "client:idle": true, "client:component-hydration": "idle", "client:component-path": "~/components/ToggleSidebarButton.svelte", "client:component-export": "default" }, { "default": ($$result3) => renderTemplate`${maybeRenderHead($$result3)}<svg aria-label="Setting Icon" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="24" height="24" viewBox="0 0 24 24" class="astro-J7PV25F6"><path fill="currentcolor" d="M19.14 12.94c.04-.3.06-.61.06-.94 0-.32-.02-.64-.07-.94l2.03-1.58c.18-.14.23-.41.12-.61l-1.92-3.32c-.12-.22-.37-.29-.59-.22l-2.39.96c-.5-.38-1.03-.7-1.62-.94l-.36-2.54c-.04-.24-.24-.41-.48-.41h-3.84c-.24 0-.43.17-.47.41l-.36 2.54c-.59.24-1.13.57-1.62.94l-2.39-.96c-.22-.08-.47 0-.59.22L2.74 8.87c-.12.21-.08.47.12.61l2.03 1.58c-.05.3-.09.63-.09.94s.02.64.07.94l-2.03 1.58c-.18.14-.23.41-.12.61l1.92 3.32c.12.22.37.29.59.22l2.39-.96c.5.38 1.03.7 1.62.94l.36 2.54c.05.24.24.41.48.41h3.84c.24 0 .44-.17.47-.41l.36-2.54c.59-.24 1.13-.56 1.62-.94l2.39.96c.22.08.47 0 .59-.22l1.92-3.32c.12-.22.07-.47-.12-.61l-2.01-1.58zM12 15.6c-1.98 0-3.6-1.62-3.6-3.6s1.62-3.6 3.6-3.6 3.6 1.62 3.6 3.6-1.62 3.6-3.6 3.6z" class="astro-J7PV25F6"></path></svg>` })}${renderComponent($$result2, "BirthdayParty", BirthdayParty, { "client:idle": true, "client:component-hydration": "idle", "client:component-path": "~/components/BirthdayParty.svelte", "client:component-export": "default", "class": "astro-J7PV25F6" })}${renderComponent($$result2, "Footer", $$Footer, { "class": "astro-J7PV25F6" })}` })}`;
}, "/Volumes/source-code/rofi/age-calculator-astro/src/pages/index.astro");

const $$file = "/Volumes/source-code/rofi/age-calculator-astro/src/pages/index.astro";
const $$url = "";

const index = /*#__PURE__*/Object.freeze(/*#__PURE__*/Object.defineProperty({
    __proto__: null,
    default: $$Index,
    file: $$file,
    url: $$url
}, Symbol.toStringTag, { value: 'Module' }));

export { escape as a, create_ssr_component as c, each as e, index as i };
