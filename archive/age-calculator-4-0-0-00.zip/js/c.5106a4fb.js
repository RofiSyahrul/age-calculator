const AgeUnit_astro_astro_type_style_index_0_lang = '';

const Age_astro_astro_type_style_index_0_lang = '';

const BirthdayParty_svelte_svelte_type_style_lang = '';

const Footer_astro_astro_type_style_index_0_lang = '';

const CloseButton_astro_astro_type_style_index_0_lang = '';

const ColorPicker_svelte_svelte_type_style_lang = '';

const DatePicker_svelte_svelte_type_style_lang = '';

const ResetColorButton_svelte_svelte_type_style_lang = '';

const Sidebar_astro_astro_type_style_index_0_lang = '';

const _global = '';

const button = '';

const index_astro_astro_type_style_index_0_lang = '';

const index_astro_astro_type_style_index_1_lang = '';

const Confetti_svelte_svelte_type_style_lang = '';
